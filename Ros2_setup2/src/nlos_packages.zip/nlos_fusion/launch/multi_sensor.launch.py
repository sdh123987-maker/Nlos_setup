import os
import yaml
from datetime import datetime
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, ExecuteProcess, IncludeLaunchDescription, TimerAction, LogInfo)
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def count_enabled_radars(yaml_path):
    """multi_radar.yaml에서 enabled: true인 레이더 ID 목록 반환"""
    try:
        with open(yaml_path, 'r') as f:
            config = yaml.safe_load(f)
        
        params = config.get('/multi_radar_manager', {}).get('ros__parameters', {})
        
        enabled_ids = []
        for i in range(4):  # MAX_RADARS = 4
            radar_key = f'radar_{i}'
            radar_cfg = params.get(radar_key, {})
            if isinstance(radar_cfg, dict) and radar_cfg.get('enabled', False):
                enabled_ids.append(i)
        
        return enabled_ids
    except Exception as e:
        print(f"⚠️ YAML 파싱 실패: {e}, 기본값 [0, 1] 사용")
        return [0, 1]


def generate_launch_description():
    pkg_fusion = get_package_share_directory('nlos_fusion')
    pkg_radar = get_package_share_directory('nlos_awr2944')
    pkg_camera = get_package_share_directory('realsense2_camera')
    
    # ============================================================
    # YAML에서 활성 레이더 자동 감지
    # ============================================================
    yaml_path = os.path.join(pkg_radar, 'config', 'multi_radar.yaml')
    enabled_radar_ids = count_enabled_radars(yaml_path)
    num_radars = len(enabled_radar_ids)
    
    # Rosbag 경로
    workspace_dir = os.path.expanduser('~/Nlos/Ros2_setup')
    rosbag_dir = os.path.join(workspace_dir, 'rosbag')
    os.makedirs(rosbag_dir, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    rosbag_path = os.path.join(rosbag_dir, f'sync_multi_{timestamp}')

    args = [
        DeclareLaunchArgument('enable_lidar', default_value='false', description='Enable Ouster Lidar'),
        DeclareLaunchArgument('record_bag', default_value='true', description='Record Synced Topics'),
    ]

    # 1. 카메라 (RealSense)
    camera_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(pkg_camera, 'launch', 'rs_launch.py')),
        launch_arguments={
            'enable_color': 'true',
            'enable_depth': 'false',
            'rgb_camera.profile': '640,480,30',
            'pointcloud.enable': 'false'
        }.items()
    )

    # 2. 멀티 레이더
    radar_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(pkg_radar, 'launch', 'multi_radar.launch.py')),
        launch_arguments={'use_rviz': 'false'}.items()
    )

    # 3. 오디오
    audio_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(pkg_fusion, 'launch', 'audio.launch.py'))
    )

    # 4. 동기화 노드 (num_radars를 yaml에서 자동 감지한 값 사용)
    sync_node = Node(
        package='nlos_fusion',
        executable='multi_sensor_sync',
        name='multi_sensor_sync',
        output='screen',
        parameters=[{
            'num_radars': num_radars,
            'enable_lidar': False,
            'enable_camera': True,
            'enable_audio': True,
        }]
    )

    # 5. Rosbag 토픽 (활성 레이더에 따라 동적 생성)
    topics_to_record = [
        '/sync/timestamp',
        '/sync/frame_info',
        '/sync/camera/color',
        '/sync/audio/spectrum',
        '/sync/audio/direction',
        '/sync/radar/merged/points',
        '/tf', '/tf_static',
    ]
    for rid in enabled_radar_ids:
        prefix = f'/sync/radar_{rid}'
        topics_to_record += [
            f'{prefix}/points',
            f'{prefix}/heatmap',
            f'{prefix}/range_profile',
            f'{prefix}/noise_profile',
        ]
    
    # QoS 오버라이드 YAML 생성 (rosbag이 reliable로 구독하도록)
    qos_override_path = os.path.join(rosbag_dir, f'qos_override_{timestamp}.yaml')
    qos_overrides = {}
    for topic in topics_to_record:
        if topic in ['/tf', '/tf_static']:
            continue
        qos_overrides[topic] = {
            'reliability': 'reliable',
            'durability': 'volatile',
            'history': 'keep_last',
            'depth': 30,
        }
    
    import yaml as yaml_lib
    with open(qos_override_path, 'w') as f:
        yaml_lib.dump(qos_overrides, f, default_flow_style=False)
    
    rosbag_cmd = [
        'ros2', 'bag', 'record',
        '-o', rosbag_path,
        '--qos-profile-overrides-path', qos_override_path,
        '--max-cache-size', '200000000',  # 200MB 캐시 (디스크 I/O 버퍼링)
    ] + topics_to_record
    rosbag_process = ExecuteProcess(
        cmd=rosbag_cmd,
        output='screen',
        condition=IfCondition(LaunchConfiguration('record_bag'))
    )

    # 6. RViz
    rviz_config = os.path.join(pkg_fusion, 'rviz', 'multi_sensor.rviz')
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        arguments=['-d', rviz_config],
        output='screen'
    )

    # 실행 순서
    radar_ids_str = ', '.join([f'radar_{i}' for i in enabled_radar_ids])
    return LaunchDescription(args + [
        LogInfo(msg=f"🚀 Multi-Sensor Launch v4 (Radar-Triggered Sync)"),
        LogInfo(msg=f"📡 Active radars ({num_radars}): {radar_ids_str}"),
        LogInfo(msg=f"📁 Rosbag path: {rosbag_path}"),
        camera_launch,
        TimerAction(period=2.0, actions=[radar_launch]),
        TimerAction(period=3.0, actions=[audio_launch]),
        TimerAction(period=5.0, actions=[sync_node]),
        TimerAction(period=7.0, actions=[rosbag_process]),
        rviz_node,
    ])